Included and Redistributed Files
---------------------------------

17 files are included in the source distribution tar. They are used to verify the standard functions of
this library. They are mandatory to run `pytest` but not required to make the lib usable after install.
They DO NOT guarantee that the detection-coverage will not regress.

Those are EITHER pulled from Wikipedia _(CC-BY-SA)_ OR public domain archive.
You SHALL NOT modify any of those files without explicit approval.
