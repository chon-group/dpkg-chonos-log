Pool Manager
============

.. autoclass:: urllib3.PoolManager
    :members:
    :undoc-members:
    :show-inheritance:
    :inherited-members:

.. autoclass:: urllib3.ProxyManager
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: urllib3.poolmanager.PoolKey
    :members:
    :undoc-members:
    :show-inheritance:
