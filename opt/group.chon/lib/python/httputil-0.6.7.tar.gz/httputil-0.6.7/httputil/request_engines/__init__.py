"""HTTP request engine implementations.
"""

__author__ = 'vovanec@gmail.com'
